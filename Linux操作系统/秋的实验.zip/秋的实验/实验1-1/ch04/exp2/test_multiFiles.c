#include <stdio.h>
#include "display.h"

int main()
{
    display( "Hello Makefile, this is a multi-files program" );
    return 0;
}
