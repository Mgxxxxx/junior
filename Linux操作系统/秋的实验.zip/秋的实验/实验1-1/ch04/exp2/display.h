#ifndef DISPLAY_H_
#define DISPLAY_H_
void display(const char* str);
#endif
