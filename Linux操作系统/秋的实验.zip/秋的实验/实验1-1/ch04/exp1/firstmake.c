#include <stdio.h>

int main()
{
    printf("Hello, the first makefile.\n");
    return 0;
}
