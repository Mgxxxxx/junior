#include <stdio.h>
#include "display.h"

void display( const char * str )
{
    printf( "The string is: '%s'\n", str );
}
